def test_my_sum():
    assert sum([3, 9, 27]) == 39

def test_my_sum_tuple():
    assert sum((4,16,61)) == 84
try:
    if __name__ == "__main__":
        test_my_sum()
        test_my_sum_tuple()
        print("Everything passed")
except:
    print("FAILED!!!")